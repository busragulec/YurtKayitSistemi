﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace YurtKayitSistem
{
    public partial class FrmPersonelGiris : Form
    {
        public FrmPersonelGiris()
        {
            InitializeComponent();
        }

        SqlBaglantim bgl = new SqlBaglantim();
        private void BtnGirisYap_Click(object sender, EventArgs e)
        {
            SqlCommand komut = new SqlCommand("select * from Personel where PersonelAdSoyad=@p1 and PersonelSifre=@p2", bgl.baglanti());
            komut.Parameters.AddWithValue("@p1", TxtPerAdSoyad.Text);
            komut.Parameters.AddWithValue("@p2", TxtPerSifre.Text);
            SqlDataReader oku = komut.ExecuteReader();
            if (oku.Read())
            {
                FrmPerAnaSayfa fr = new FrmPerAnaSayfa ();
                fr.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Hatalı Ad Soyad Veya Şifre Girdiniz.");
                TxtPerAdSoyad.Clear();
                TxtPerSifre.Clear();
                TxtPerAdSoyad.Focus();
            }
            bgl.baglanti().Close();
        }
    }
}
