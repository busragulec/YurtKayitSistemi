﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.OleDb;

namespace YurtKayitSistem
{
    public partial class FrmExcel : Form
    {
        public FrmExcel()
        {
            InitializeComponent();
        }

        SqlBaglantim bgl = new SqlBaglantim();

        public string dosyayolu;
        private void BtnOdemeAl_Click(object sender, EventArgs e)
        {
            OpenFileDialog file = new OpenFileDialog();
            file.RestoreDirectory = true;
            file.CheckFileExists = false;
            file.Title = "Excel Dosyası Seçiniz..";
            file.Multiselect = false;

            try
            {
                if (file.ShowDialog() == DialogResult.OK)
                {
                    dosyayolu = file.FileName;

                    OleDbConnection baglanti = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + dosyayolu + "; Extended Properties='Excel 12.0 xml;HDR=YES;'");
                    baglanti.Open();
                    OleDbDataAdapter da = new OleDbDataAdapter("SELECT * FROM [Sayfa1$]", baglanti);
                    DataSet dt = new DataSet();
                    da.Fill(dt, "ExcelBilgi");
                    dataGridView1.DataSource = dt.Tables["ExcelBilgi"].DefaultView;
                    baglanti.Close();

                }

                string sorgu = "insert into  Ogrenci(OgrAd, OgrSoyad, OgrTc,OgrTelefon, OgrDogum, OgrMail)values(@ad,@soyad,@tc,@tel,@dt,@mail)"; 
                SqlCommand komut2 = new SqlCommand(sorgu, bgl.baglanti());
                for (int i = 1; i < dataGridView1.Rows.Count - 1; i++)
                {
                    komut2.Parameters.AddWithValue("@ad", dataGridView1.Rows[i].Cells[1].Value.ToString());
                    komut2.Parameters.AddWithValue("@soyad", dataGridView1.Rows[i].Cells[2].Value.ToString());
                    komut2.Parameters.AddWithValue("@tc", dataGridView1.Rows[i].Cells[3].Value.ToString());
                    komut2.Parameters.AddWithValue("@tel", dataGridView1.Rows[i].Cells[4].Value.ToString());
                    komut2.Parameters.AddWithValue("@dt", dataGridView1.Rows[i].Cells[5].Value.ToString());
                    komut2.Parameters.AddWithValue("@mail", dataGridView1.Rows[i].Cells[6].Value.ToString());

                    komut2.ExecuteNonQuery();
                }
                bgl.baglanti().Close();

                MessageBox.Show("Excelden veri aktarımı gerçekleşti.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);


            }
            catch (Exception hata)
            {
                MessageBox.Show(hata.Message);
            }
        }
    }
}
